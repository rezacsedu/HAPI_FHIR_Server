const mongoose = require('mongoose')

let UserSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String
})

UserSchema.methods.authenticate = function (password) {
  return this.password === password;
};

module.exports = mongoose.model('User', UserSchema)