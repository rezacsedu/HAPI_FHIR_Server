const User = require('../models/User')
const winston  = require('winston');

const logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.label({ label: 'fhir-client' }),
    winston.format.timestamp(),
    winston.format.printf(info => `${info.timestamp} [${info.label}] ${info.level}: ${info.message}`)
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'server_log.log' })
  ]
});

module.exports = {
  register: (req, res, next) => {
    User.findOne({
      email: req.body.email
    }, function (err, user) {
      if (err) {
        logger.error(err); 
        res.status(400).send();
      }

      if (user) {
        logger.error("User " + req.body.email + " is exist!");
        res.status(400).send();
      } else {
        new User(req.body).save((err, newUser) => {
          if (err) {
            logger.error(err);
            res.send(err);
          } else if (!newUser) {
            logger.error("Cannot create user " + req.body.email);
            res.status(400).send();
          } else {
            res.send(newUser);
          }
        });
      }
    });
  },
  login: (req, res, next) => {
    User.findOne({
      email: req.body.username
    }, function (err, user) {
      if (err) {
        logger.error(err);
        res.send(err);
      }
      if (!user || !user.authenticate(req.body.password)) {
        logger.error("Username " + req.body.username + " and password is invalid!");
        res.status(400).send();
      } else {
        res.send(user);
      }
    });
  },
}