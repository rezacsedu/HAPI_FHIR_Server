const controller = require('./../controllers/auth.ctrl')

module.exports = (router) => {
  router.route('/auth/login').post(controller.login);
  router.route('/auth/register').post(controller.register);
}