# Create-React-Redux

## Table of Contents

- [Installation](#installation)

## Installation

1. Clone this repository: `git clone git@github.com:kugoo109/create-react-redux.git <project-name>`
2. Go to `<project-name>`
3. Run the following commands:
    1. `yarn`
    2. `yarn start`

You can now visit the app in your browser by visiting [http://localhost:3000](http://localhost:3000)
