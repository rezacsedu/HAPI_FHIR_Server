const express = require('express'); 
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const helmet = require('helmet');
const path = require('path');
const webpack = require('webpack');
const webpackMiddleware = require('webpack-dev-middleware');
const webpackConfig = require('./webpack.config.js');
const routes = require('./server/routes');

const app = express();
const router = express.Router();
routes(router)

mongoose.connect("mongodb://cloud39.dbis.rwth-aachen.de:27017/fairship", function (err) {
  if (err) {
    console.error(chalk.red('Could not connect to MongoDB!'));
    console.log(err);
  } else {
    console.info('Connect Mongodb successfully!!!');
  }
});

app.use(cors())
app.use(bodyParser.json())
app.use(helmet())

app.use(webpackMiddleware(webpack(webpackConfig)));

app.use('/', express.static('public'))
app.use('/libs', express.static('node_modules'))
app.use('/api', router)
app.get('*', function(request, response) {
  response.sendFile(path.resolve(__dirname, './public', 'index.html'));
});

app.listen(3000, () => {
  console.info('Listening on port 3000');
});
