import axios from 'axios';
import { apiUrl, config } from '../services/api';
import * as actionTypes from '../constants/actionTypes';

export const checkme = () => (dispatch) => {
  return new Promise((resolve, reject) => {
    const user = JSON.parse(sessionStorage.getItem('user'));
    dispatch({ type: actionTypes.SET_USER, user: user });
    if(user) {
      resolve(user);
    } else {
      reject(user);
    }
  });
};

export const register = (user) => (dispatch) => {
  return axios.post(apiUrl('auth/register'), user, config)
    .then((res) => {
      sessionStorage.setItem('user', JSON.stringify(res.data));
      dispatch({ type: actionTypes.SET_USER, user: res.data });
    });
};

export const login = (username, password) => (dispatch) => {
  return axios.post(apiUrl('auth/login'), { username, password }, config)
    .then((res) => {
      sessionStorage.setItem('user', JSON.stringify(res.data));
      dispatch({ type: actionTypes.SET_USER, user: res.data });
    });
};

export const logout = () => (dispatch) => {
  return new Promise((resolve, reject) => {
    sessionStorage.setItem('user', null);
    dispatch({ type: actionTypes.RESET_AUTH });
    resolve();
  });
};

