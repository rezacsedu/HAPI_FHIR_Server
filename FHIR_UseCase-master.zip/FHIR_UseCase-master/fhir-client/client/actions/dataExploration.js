import axios from 'axios';
import { fhirApi, fhirApiUrl } from '../services/api';
import * as actionTypes from '../constants/actionTypes';

export const getResources = (type) => (dispatch) => {
  return fhirApi.fetchAll({ type })
    .then(data => {
      dispatch({ type: actionTypes.GET_RESOURCES, payload: {
        type, 
        items: data,
      }});
    });
};

export const setFilterParam = (key, value) => (dispatch) => {
  return dispatch({ type: actionTypes.SET_FILTER_PARAM, key, value });
};

export const setChartType = (value) => (dispatch) => {
  return dispatch({ type: actionTypes.SET_CHART_TYPE, value });
};
