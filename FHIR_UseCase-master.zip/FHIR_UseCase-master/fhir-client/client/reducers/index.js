import { combineReducers } from 'redux';
import auth from './auth';
import dataExploration from './dataExploration';

export default combineReducers({
  auth,
  dataExploration,
});
