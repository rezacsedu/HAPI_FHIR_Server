import * as actionTypes from '../constants/actionTypes';

export default (state = {
  type: 'Patient',
  items: [],
  filterParams: {},
}, action) => {
  switch (action.type) {
    case actionTypes.GET_RESOURCES:
      return {
        ...state,
        type: action.payload.type,
        items: action.payload.items,
      };
    case actionTypes.SET_FILTER_PARAM:
      let filterParams = state.filterParams;
      filterParams[action.key] = action.value;
      return {
        ...state,
        filterParams
      };
    case actionTypes.SET_CHART_TYPE:
      return {
        ...state,
        chartType: action.value
      };
    default:
      return state;
  }
};
