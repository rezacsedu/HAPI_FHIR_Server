export const SET_USER = 'SET_USER';
export const RESET_AUTH = 'RESET_AUTH';
export const GET_RESOURCES = 'GET_RESOURCES';
export const SET_FILTER_PARAM = 'SET_FILTER_PARAM';
export const SET_CHART_TYPE = 'SET_CHART_TYPE';