import nativeFhir from "../fhir.js/src/adapters/native"

export const config = {
  headers: {
    'Content-Type': 'application/json',
  },
};

export function apiUrl(url) {
  return `/api/${url || ''}`;
};

export function fhirApiUrl(url) {
  return `http://cloud39.dbis.rwth-aachen.de:8080/baseDstu3`;
  // return `https://sb-fhir-stu3.smarthealthit.org/smartstu3/open/${url}`;
};

export const fhirApi = nativeFhir({
  baseUrl: fhirApiUrl(),
  credentials: 'same-origin',
});