import moment from 'moment';

export function getPath(obj, path = "") {
  return path.split(".").reduce((out, key) => out ? out[key] : undefined, obj)
}

export function getAge(birthdate) {
  let birthDate = moment(birthdate, "YYYY-MM-DD");
  return moment().diff(birthDate, 'years');
}

export function getFullname(name) {
  if (name ) {
    return name[0].given.join(" ") + " " + name[0].family;
  }
  return "N/A";
}

function getLine(address) {
  if (address[0].line) {
    return address[0].line.join(", ") + ", ";
  }
  return "";
}

export function getAddress(address) {
  if (address){
    console.log(address[0]);
    return getLine(address) + address[0].city + ", " + address[0].postalCode + " " + address[0].country;
  }
  return "N/A";
}

export function getEncounterClass(encounter) {
  return encounter.class && typeof encounter.class == "object" ?
      getPath(encounter, "class.type.0.text") :
      encounter.class;
}

export function getEncounterLabel(encounter) {
  let result = getPath(encounter, "type.0.text");
  if (result) {
      return result;
  }
  let _class = getEncounterClass(encounter);
  if (_class) {
      return _class + " encounter";
  }
  return "";
}
