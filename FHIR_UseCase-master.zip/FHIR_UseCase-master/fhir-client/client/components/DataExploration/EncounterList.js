import React from 'react';
import map from 'lodash/fp/map';
import { getPath, getEncounterLabel } from '../../services/fhir';
import getPeriod from './Period';

function EncounterList(props) {
  const { resources } = props;
  return (
    <div>
      <h2>Encounter</h2>
      <div className="table-responsive">
        <table className="table table-striped table-sm">
          <thead>
            <tr>
              <th>Id</th>
              <th>Type</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            { 
              map((obj) => {
                let resource = obj;
                return (
                  <tr key={resource.id}>
                    <td>{ resource.id }</td>
                    <td>{ getEncounterLabel(resource) }</td>
                    <td>{ getPath("reason.0.coding.0.display") || "N/A" }</td>
                    <td>{ resource.status }</td>
                    <td>{ getPeriod(resource.period) }</td>
                  </tr>
                );
              }, resources) 
            }
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default EncounterList;