import React from 'react';
import { connect } from 'react-redux'
import _ from 'lodash/fp';
import moment from 'moment';
import { getAge, getFullname } from '../../services/fhir';
import { Bar, Pie } from 'react-chartjs-2'

function Chart(props) {
  const { type, items } = props;
  const color = ['#ff6384', '#36a2eb', '#cc65fe', '#ffce56'];
  const options = {
    scales: {
      xAxes: [{
        stacked: true,
      }],
      yAxes: [{
        stacked: true
      }]
    }
  };

  var labels = [],
    data = [],
    chartData;

  if (type == 'Patient') {
    labels = _.map(item => {
      return getFullname(item.name);
    }, items);

    data = _.map(item => {
      return getAge(item.birthDate);
    }, items);

    chartData = {
      labels: labels,
      datasets: [{
        label: "",
        backgroundColor: color[1],
        data: data,
      }]
    };
  } else if (type == 'Encounter') {
    let groupedItems = _.groupBy(item => {
      return moment(item.period.start).year();
    }, items);

    let group1 = _.map(months => {
      return _.filter(item => item.status == 'in-progress', months).length;
    }, groupedItems);

    let group2 = _.map(months => {
      return _.filter(item => item.status == 'finished', months).length;
    }, groupedItems);

    labels = Object.keys(groupedItems);

    chartData = {
      labels: labels,
      datasets: [{
        label: "finished",
        backgroundColor: color[1],
        data: group2,
      },{
        label: "in-progress",
        backgroundColor: color[0],
        data: group1,
      }]
    };
  }


  var labels2 = [],
    data2 = [];

  if (type == 'Patient') {
    data2 = _.countBy(item => item.gender, items);
  } else if (type == 'Encounter') {
    data2 = _.countBy(item => item.status, items);
  }

  const chartData2 = {
    datasets: [{
      data: Object.values(data2),
      backgroundColor: color,
    }],
    labels: Object.keys(data2)
  };
  
  return (
    <div>
      <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h4 className="">Interactive chart</h4>
        <div className="btn-toolbar mb-2 mb-md-0">
          <div className="btn-group mr-2">
            <button className="btn btn-sm btn-outline-secondary">Share</button>
            <button className="btn btn-sm btn-outline-secondary">Export</button>
          </div>
        </div>
      </div>
      <Bar data={chartData} options={options} />
      <Pie data={chartData2} />
    </div>
  );
}

export default Chart;