import React from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as actions from '../../actions/index'
import { RangeSlider } from "@blueprintjs/core";
import { getAge, getFullname } from '../../services/fhir';
import _ from 'lodash/fp';
import * as d3 from "d3-array";

const mapStateToProps = state => ({
});

const mapDispatchToProps = dispatch => ({
  getResources: bindActionCreators(actions.getResources, dispatch),
  setFilterParam: bindActionCreators(actions.setFilterParam, dispatch),
  setChartType: bindActionCreators(actions.setChartType, dispatch),
});

class Explorer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      method: '',
      range: [0, 100]
    };

    this.handleDataChange = this.handleDataChange.bind(this);
    this.handleChartTypeChange = this.handleChartTypeChange.bind(this);
    this.handleValueChange = this.handleValueChange.bind(this);
    this.handleInputChange = this.handleInputChange.bind(this);
  }
  
  handleInputChange(event) {
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;
    this.setState({
      [name]: value
    });
  }

  handleDataChange(e) {
    this.props.getResources(e.target.value);
  }

  handleChartTypeChange(e){
    this.props.setChartType(e.target.value);
  } 

  handleValueChange(value){
    this.setState({range: value});
    this.props.setFilterParam('age', {
      property: 'birthDate',
      type: 'range',
      value
    });
  } 

  render() {
    const { method } = this.state;
    const { type, data, chartType } = this.props;

    var properties;
    let methodValue;
    
    if(type == "Patient") {
      properties = ["Age"];
      if (method != '') {
        methodValue = d3[method](data, (d) => getAge(d.birthDate));
      }
    } else if (type == "Encounter") {
      properties = ["Period"];
    }

    return (
      <div>
        <h4 className="d-flex justify-content-between align-items-center mb-3">
          Explorer
        </h4>
        <div className="card p-2">

          <label htmlFor="data">Data</label>
          <div className="input-group">
            <select className="custom-select d-block w-100" name="type"
              value={type}
              onChange={this.handleDataChange}>
              <option value="">Choose...</option>
              <option value="Patient" selected>Patient</option>
              <option value="Encounter">Encounter</option>
            </select>
          </div>
          <hr className="mb-2" />

          <label htmlFor="chartType">Chart Type</label>
          <div className="input-group">
            <select className="custom-select d-block w-100" name="chartType"
              value={chartType}
              onChange={this.handleChartTypeChange}>
              <option value="">Choose...</option>
              <option value="Bar">Bar Chart</option>
              <option value="Pie">Pie Chart</option>
            </select>
          </div>
          <hr className="mb-2" />

          <div className="d-flex justify-content-between lh-condensed">
            <label htmlFor="chartType">Calculate</label>
           <span className="text-muted">{methodValue}</span>
          </div>
          <div className="input-group">
            <select className="custom-select d-block w-100" name="method"
              value={method}
              onChange={this.handleInputChange}>
              <option value="">Choose...</option>
              <option value="max">Max</option>
              <option value="min">Min</option>
              <option value="mean">Mean</option>
              <option value="median">Median</option>
              <option value="deviation">Deviation</option>
            </select>
          </div>
          <hr className="mb-2" />

          <label htmlFor="property">Property</label>
          <div className="input-group">
            <select className="custom-select d-block w-100" name="property">
              <option value="">Choose...</option>
              <option selected>Age</option>
              {/* { 
                _.map((prop) => {
                  return (
                    <option>{prop}</option>
                  );
                }, properties) 
              } */}
            </select>
          </div>
          <hr className="mb-2" />
          <div className="input-group">
            <RangeSlider
              min={0}
              max={100}
              stepSize={2}
              labelStepSize={20}
              onChange={this.handleValueChange}
              value={this.state.range}
              vertical={false}
            />
          </div>
         
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Explorer);