import React from 'react';
import map from 'lodash/fp/map';
import { getFullname, getAddress } from '../../services/fhir';

function PatientList(props) {
  const { resources } = props;
  return (
    <div>
      <h2>Patient</h2>
      <div className="table-responsive">
        <table className="table table-striped table-sm">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Gender</th>
              <th>BirthDate</th>
              <th>Address</th>
            </tr>
          </thead>
          <tbody>
            { 
              map((obj) => {
                let patient = obj;
                return (
                  <tr key={patient.id}>
                    <td>{ patient.id }</td>
                    <td>{ getFullname(patient.name) }</td>
                    <td>{ patient.gender }</td>
                    <td>{ patient.birthDate }</td>
                    <td>{ getAddress(patient.address) }</td>
                  </tr>
                );
              }, resources) 
            }
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default PatientList;