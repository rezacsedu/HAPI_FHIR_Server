import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actions from '../../actions/index';
import map from 'lodash/fp/map';
import { getAge, getFullname } from '../../services/fhir';

import Explorer from './Explorer';
import Chart from './Chart';
import PatientList from './PatientList';
import EncounterList from './EncounterList';

const mapStateToProps = state => ({
  ...state.dataExploration,
  items: filter(state.dataExploration.items, state.dataExploration.filterParams),
});

const mapDispatchToProps = dispatch => ({
  getResources: bindActionCreators(actions.getResources, dispatch),
});

function filter (items, filterParams) {
  let filteredItems = items;
  Object.keys(filterParams).forEach(key => {
    let element = filterParams[key];
    if (element.type == "range") {
      filteredItems = filteredItems.filter((item) => {
        let resource = item;
        let value = getAge(resource[element.property]); // TODO: 
        return value > element.value[0] && value <= element.value[1];
      });
    }
  });
  return filteredItems;
}

class DataExploration extends React.Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.getResources(this.props.type);
  }

  renderResources(type) {
    const { items } = this.props;

    switch (type) {
      case 'Patient':
        return <PatientList resources={items} />;
      case 'Encounter':
        return <EncounterList resources={items} />;
    }
  }

  render() {
    const { type, items, chartType } = this.props;
    return (
      <main role="main">
        <div className="jumbotron">
          <div className="container">
            <ul className="nav nav-tabs mb-4">
              <li className="nav-item">
                <a className="nav-link active" data-toggle="tab" href="#interactiveChart">Interactive chart</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" data-toggle="tab" href="#dataExplorer">Data explorer</a>
              </li>
            </ul>
            <div className="tab-content">
              <div className="tab-pane container active" id="interactiveChart">
                <div className="row">
                  <div className="col-md-4 order-md-1 mb-4">
                    <Explorer type={type} data={items} chartType={chartType} />
                  </div>
                  <div className="col-md-8 order-md-2">
                    <Chart type={type} chartType={chartType} items={items}/>
                  </div>
                  <hr className="mb-4" />
                </div>
              </div>
              <div className="tab-pane container fade" id="dataExplorer">
                <div className="row">
                  <div className="col-md-12 mb-12">
                    { this.renderResources(type) }
                    <hr className="mb-4" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(DataExploration);
