import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actions from '../actions/index';

const mapStateToProps = state => ({
});

const mapDispatchToProps = dispatch => ({
  login: bindActionCreators(actions.login, dispatch),
});

class Login extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
    };
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleInputChange(event) {
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;
    this.setState({
      [name]: value
    });
  }

  handleSubmit(event) {
    event.preventDefault();
    const { history } = this.props;
    this.props.login(this.state.username, this.state.password).then(function() {
        history.push('/');
      }).catch(function(error) {
        alert("Unable to login");
      });
  }

  render() {
    return (
      <form className="form-signin" onSubmit={this.handleSubmit}>
        <div className="text-center mb-4">
          <img className="mb-4" src="imgs/logo.png" alt="" width="360" height="127"/>
          <h3>Welcome to FAIRship</h3>
          <p>Login in. To see it in action.</p>
        </div>

        <div className="form-label-group">
          <input type="email" id="inputEmail" name="username" className="form-control" placeholder="Email address" 
            value={this.state.username}
            onChange={this.handleInputChange} 
            required/>
          <label htmlFor="inputEmail">Email address</label>
        </div>

        <div className="form-label-group">
          <input type="password" id="inputPassword" name="password"  className="form-control" placeholder="Password" 
            value={this.state.password}
            onChange={this.handleInputChange} 
            required/>
          <label htmlFor="inputPassword">Password</label>
        </div>

        <button className="btn btn-lg btn-primary btn-block" type="submit">Login</button>
        <p className="mt-5 mb-3 text-muted text-center"><small>Do not have an account?</small></p>
        <a className="btn btn-sm btn-white btn-block" href="/register">Create an account</a>
      </form>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);
