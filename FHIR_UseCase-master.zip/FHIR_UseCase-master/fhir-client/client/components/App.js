import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import TRoute from './TRoute';

import Header from './Header';
import Footer from './Footer';
import Main from './Main';
import Home from './Home';
import DataExploration from './DataExploration';
import Login from './Login';
import Register from './Register';
import About from './About';

class App extends React.Component {
  render() {
    return (
      <div>
        <Switch>
          <Route path="/login" component={Login}/>
          <Route path="/register" component={Register}/>
          <TRoute exact path="/" component={Home} template={Main} requireAuth/>
          <TRoute exact path="/dataExploration" component={DataExploration} template={Main} requireAuth/>
          <TRoute exact path="/about" component={About} template={Main} requireAuth/>
          <Redirect to="/"/>
        </Switch>
      </div>
    );
  }
}

export default App;
