import React from 'react';

class Home extends React.Component {
  render() {
    return (
      <main role="main">
        <div className="jumbotron">
          <div className="container">
            <h1>Welcome to FAIRship!</h1>
            <p>FAIRship is a platform which implements Personal Health Train concept to enable researchers to gain the full benefit of the health care data, without sharing the data with third parties. With this approach data scientist can develop their models and test their hypothesis by sending their algorithms to the data integration centers.</p>
            <p>The FAIRship platform provides tools to researchers to describe algorithms and the data requirements of them as trains, ship it to the stations where they can be executed. Trained models leaves the station , but data is not allowed to leave the origin.</p>
          </div>
        </div>
      </main>
    );
  }
}

export default Home;
