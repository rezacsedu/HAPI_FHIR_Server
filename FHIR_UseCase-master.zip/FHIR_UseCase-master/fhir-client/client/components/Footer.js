import React from 'react';

class Footer extends React.Component {
  render() {
    return (
      <footer className="footer ft-dark bg-i5">
        <div className="container">
          <div className="row d-flex justify-content-between align-items-center">
            <div className="flex-col-md-6 py-2">
              <p className="text-center my-0">This website is currently available as an "early-access".<br/>
              Copyright © 2018 Personal Health Train. All Rights Reserved</p>
            </div>
            <div className="flex-col-md-2 py-2">
              <a href="https://abi.inf.uni-tuebingen.de/People/kohlbach">
                <img src="imgs/com_5.png" alt="" height="65" />
              </a>
            </div>
            <div className="flex-col-md-2 py-2">
              <a href="http://dbis.rwth-aachen.de/cms">
                <img src="imgs/com_3.jpg" alt="" />
              </a>
            </div>
            <div className="flex-col-md-2 py-2">
              <a href="https://www.fit.fraunhofer.de/en.html">
                <img src="imgs/com_1.jpg" alt="" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer;
