import React from 'react';
import { Route } from 'react-router';
import { connect } from 'react-redux';
import { push } from 'react-router-redux'
import { bindActionCreators } from 'redux';
import * as actions from '../actions/index';

function TComponent(Template, Component, requireAuth) {
  class Authentication extends React.Component {
    componentWillMount() {
      if (requireAuth && !this.props.user) {
        const { history, location } = this.props;
        const returnPath = location.pathname;
        this.props.checkme().then(function() {
          history.push(returnPath);
        }).catch(function() {
          history.push('/login');
        });
      }
    }

    componentWillUpdate(nextProps) {
      if (requireAuth && !nextProps.user) {
        this.props.history.push('/login');
      }
    }

    render() {
      if (requireAuth && !this.props.user) {
        return (<div/>);
      }
      
      return (
        <Template>
          <Component {...this.props}/>
        </Template>
      );
    }
  }

  const mapStateToProps = state => ({
    ...state.auth
  });

  const mapDispatchToProps = dispatch => ({
    checkme: bindActionCreators(actions.checkme, dispatch),
  });
  
  return connect(mapStateToProps, mapDispatchToProps)(Authentication);
}

function TRoute({ template: Template, component: Component, requireAuth, ...rest }) {
  return (
    <Route {...rest} component={TComponent(Template, Component, requireAuth)} />
  );
}

export default TRoute;
