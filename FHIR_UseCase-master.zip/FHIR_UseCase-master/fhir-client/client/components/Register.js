import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actions from '../actions/index';

const mapStateToProps = state => ({
});

const mapDispatchToProps = dispatch => ({
  register: bindActionCreators(actions.register, dispatch),
});

class Register extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      name: '',
      email: '',
      password: '',
    };
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleInputChange(event) {
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;
    this.setState({
      [name]: value
    });
  }

  handleSubmit(event) {
    event.preventDefault();
    const { history } = this.props;
    const user = {
      name: this.state.name,
      email: this.state.email,
      password: this.state.password,
    };
    this.props.register(user).then(function() {
      history.push('/');
    }).catch(function(error) {
      alert("Unable to register");
    });
  }

  render() {
    return (
      <form className="form-signin" onSubmit={this.handleSubmit}>
        <div className="text-center mb-4">
          <img className="mb-4" src="imgs/logo.png" alt="" width="360" height="127"/>
          <h3>Register to FAIRship</h3>
          <p>Create account to see it in action.</p>
        </div>

        <div className="form-label-group">
          <input type="text" id="inputName" name="name" className="form-control" placeholder="Name" 
            value={this.state.name}
            onChange={this.handleInputChange} 
            required/>
          <label htmlFor="inputName">Name</label>
        </div>

        <div className="form-label-group">
          <input type="email" id="inputEmail" name="email" className="form-control" placeholder="Email address" 
            value={this.state.email}
            onChange={this.handleInputChange} 
            required/>
          <label htmlFor="inputEmail">Email address</label>
        </div>

        <div className="form-label-group">
          <input type="password" id="inputPassword" name="password" className="form-control" placeholder="Password" 
            value={this.state.password}
            onChange={this.handleInputChange} 
            required/>
          <label htmlFor="inputPassword">Password</label>
        </div>

        <button className="btn btn-lg btn-primary btn-block" type="submit">Register</button>
        <p className="mt-5 mb-3 text-muted text-center"><small>Already have an account?</small> <a href="/login">Login</a></p>
      </form>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Register);
