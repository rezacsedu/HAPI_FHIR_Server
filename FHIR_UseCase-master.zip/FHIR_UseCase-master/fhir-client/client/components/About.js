import React from 'react';

class About extends React.Component {
  render() {
    return (
      <p>
        About
      </p>
    );
  }
}

export default About;
