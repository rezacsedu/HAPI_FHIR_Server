import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import * as actions from '../actions/index';
import classNames from 'classnames';

const mapStateToProps = state => ({
  ...state.auth,
});

const mapDispatchToProps = dispatch => ({
  logout: bindActionCreators(actions.logout, dispatch),
});

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(e) {
    e.preventDefault();
    this.props.logout();
  }

  render() {
    const pathname = this.props.location.pathname;

    return (
      <div>
        <div className="container">
          <img className="mb-4" src="imgs/logo.png" width="227" height="80"/>
        </div>
        <nav className="navbar navbar-expand-md navbar-dark bg-i5">
          <div className="container">
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span> Menu
            </button>

            <div className="collapse navbar-collapse justify-content-md-center" id="navbarsExampleDefault">
              <ul className="navbar-nav">
                <li className={classNames('nav-item', { active: pathname == "/"})}>
                  <a className="nav-link" href="/"><i className="fa fa-home"/> Home</a>
                </li>
                <li className={classNames('nav-item', { active: pathname == "/dataExploration"})}>
                  <a className="nav-link" href="/dataExploration"><i className="fa fa-pie-chart"/> Data Exploration</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/"><i className="fa fa-puzzle-piece"/> Algorithm design</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/"><i className="fa fa-truck"/> Ship code</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/"><i className="fa fa-leanpub"/> Train monitor</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/"><i className="fa fa-life-ring"/> Contact</a>
                </li>
                <li className="nav-item dropdown">
                  <a className="nav-link dropdown-toggle" href="/" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i className="fa fa-user"/> My profile
                  </a>
                  <div className="dropdown-menu" aria-labelledby="dropdown01">
                    <a className="dropdown-item" href="/"><i className="fa fa-user-circle"/> My Account</a>
                    <a className="dropdown-item" href="/"><i className="fa fa-tasks"/> My Work</a>
                    <a className="dropdown-item" href="#" onClick={this.handleClick}><i className="fa fa-sign-out"/> Logout</a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    );
  }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Header));
